package com.smartplanters.budgeting_app.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "pruning_records")
public class Pruning {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Parameter Input
    private Double luasLahan;
    private Double pokokPerHa;
    private Double rotasi;
    private Double kemampuanTenaga;
    private Double jumlahHariKerja;
    private Double upahPerHk;
    private Double hargaEgrek;
    private Double hargaParang;
    private Double hargaApd;

    // Parameter Output
    private Double jumlahPokok;
    private Double kebutuhanTenagaPerHari;
    private Double biayaEgrek;
    private Double biayaParang;
    private Double biayaApd;
    private Double totalAnggaranLabour;
    private Double totalAnggaranTools;
    private Double grandTotalAnggaran;

    private LocalDateTime createdAt = LocalDateTime.now();

    public Pruning() {}

    // GETTERS AND SETTERS
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Double getLuasLahan() { return luasLahan; }
    public void setLuasLahan(Double luasLahan) { this.luasLahan = luasLahan; }
    public Double getPokokPerHa() { return pokokPerHa; }
    public void setPokokPerHa(Double pokokPerHa) { this.pokokPerHa = pokokPerHa; }
    public Double getRotasi() { return rotasi; }
    public void setRotasi(Double rotasi) { this.rotasi = rotasi; }
    public Double getKemampuanTenaga() { return kemampuanTenaga; }
    public void setKemampuanTenaga(Double kemampuanTenaga) { this.kemampuanTenaga = kemampuanTenaga; }
    public Double getJumlahHariKerja() { return jumlahHariKerja; }
    public void setJumlahHariKerja(Double jumlahHariKerja) { this.jumlahHariKerja = jumlahHariKerja; }
    public Double getUpahPerHk() { return upahPerHk; }
    public void setUpahPerHk(Double upahPerHk) { this.upahPerHk = upahPerHk; }
    public Double getHargaEgrek() { return hargaEgrek; }
    public void setHargaEgrek(Double hargaEgrek) { this.hargaEgrek = hargaEgrek; }
    public Double getHargaParang() { return hargaParang; }
    public void setHargaParang(Double hargaParang) { this.hargaParang = hargaParang; }
    public Double getHargaApd() { return hargaApd; }
    public void setHargaApd(Double hargaApd) { this.hargaApd = hargaApd; }
    public Double getJumlahPokok() { return jumlahPokok; }
    public void setJumlahPokok(Double jumlahPokok) { this.jumlahPokok = jumlahPokok; }
    public Double getKebutuhanTenagaPerHari() { return kebutuhanTenagaPerHari; }
    public void setKebutuhanTenagaPerHari(Double kebutuhanTenagaPerHari) { this.kebutuhanTenagaPerHari = kebutuhanTenagaPerHari; }
    public Double getBiayaEgrek() { return biayaEgrek; }
    public void setBiayaEgrek(Double biayaEgrek) { this.biayaEgrek = biayaEgrek; }
    public Double getBiayaParang() { return biayaParang; }
    public void setBiayaParang(Double biayaParang) { this.biayaParang = biayaParang; }
    public Double getBiayaApd() { return biayaApd; }
    public void setBiayaApd(Double biayaApd) { this.biayaApd = biayaApd; }
    public Double getTotalAnggaranLabour() { return totalAnggaranLabour; }
    public void setTotalAnggaranLabour(Double totalAnggaranLabour) { this.totalAnggaranLabour = totalAnggaranLabour; }
    public Double getTotalAnggaranTools() { return totalAnggaranTools; }
    public void setTotalAnggaranTools(Double totalAnggaranTools) { this.totalAnggaranTools = totalAnggaranTools; }
    public Double getGrandTotalAnggaran() { return grandTotalAnggaran; }
    public void setGrandTotalAnggaran(Double grandTotalAnggaran) { this.grandTotalAnggaran = grandTotalAnggaran; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}