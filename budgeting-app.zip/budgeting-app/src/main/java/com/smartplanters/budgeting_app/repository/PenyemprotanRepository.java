package com.smartplanters.budgeting_app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smartplanters.budgeting_app.model.Penyemprotan;

@Repository
public interface PenyemprotanRepository extends JpaRepository<Penyemprotan, Long> {
}