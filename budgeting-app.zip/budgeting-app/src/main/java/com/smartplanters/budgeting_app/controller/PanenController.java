package com.smartplanters.budgeting_app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smartplanters.budgeting_app.model.Panen;
import com.smartplanters.budgeting_app.repository.PanenRepository;

@Controller
@RequestMapping("/panen")
public class PanenController {

    @Autowired
    private PanenRepository panenRepository;

    @GetMapping
    public String showForm(Model model) {
        if (!model.containsAttribute("panen")) {
            model.addAttribute("panen", new Panen());
        }
        // Menampilkan daftar data dari database ke tabel
        model.addAttribute("listPanen", panenRepository.findAll());
        return "panen";
    }

    @PostMapping("/hitung")
    public String hitungAnggaran(@ModelAttribute Panen panen, Model model) {
        double luas = (panen.getLuasLahan() != null) ? panen.getLuasLahan() : 0.0;
        double sph = (panen.getPokokPerHa() != null) ? panen.getPokokPerHa().doubleValue() : 0.0;
        double akpVal = (panen.getAkp() != null) ? panen.getAkp() : 0.0;
        double bjr = (panen.getBjr() != null) ? panen.getBjr() : 0.0;
        double rotasi = (panen.getRotasi() != null) ? panen.getRotasi() : 0.0;
        double kemampuan = (panen.getKemampuanTenaga() != null) ? panen.getKemampuanTenaga() : 1.0;
        double interval = (panen.getIntervalPanen() != null) ? panen.getIntervalPanen().doubleValue() : 1.0;
        double upahPerTon = (panen.getUpahPerHk() != null) ? panen.getUpahPerHk() : 0.0;

        // Rumus Tonase & TK sesuai file aslimu
        double tonaseHasil = (luas * sph * (akpVal / 100.0) * bjr * rotasi) / 13.88888888888889;
        double kebTk = Math.floor((kemampuan * interval != 0) ? luas / (kemampuan * interval) : 0.0);

        // Perhitungan Anggaran Tools
        double hEgrek = (panen.getHargaEgrek() != null) ? panen.getHargaEgrek() : 0.0;
        double hTojok = (panen.getHargaTojok() != null) ? panen.getHargaTojok() : 0.0;
        double hAngkong = (panen.getHargaAngkong() != null) ? panen.getHargaAngkong() : 0.0;
        double hApd = (panen.getHargaApd() != null) ? panen.getHargaApd() : 0.0;
        double hGancu = (panen.getHargaGancu() != null) ? panen.getHargaGancu() : 0.0;

        double totalUpahKaryawan = tonaseHasil * upahPerTon;
        double anggaranTools = kebTk * (hEgrek + hTojok + hAngkong + hApd + hGancu);
        double grandTotal = totalUpahKaryawan + anggaranTools;

        panen.setTonase(tonaseHasil);
        panen.setKebutuhanTk(kebTk);
        panen.setUpahKaryawan(totalUpahKaryawan);
        panen.setTotalAnggaranLabour(totalUpahKaryawan);
        panen.setTotalAnggaranTools(anggaranTools);
        panen.setGrandTotalAnggaran(grandTotal);

        model.addAttribute("hasil", panen);
        model.addAttribute("panen", panen);
        model.addAttribute("listPanen", panenRepository.findAll());
        return "panen";
    }

    // Fungsi EDIT: Mengambil data lama untuk dimasukkan kembali ke form
    @GetMapping("/edit/{id}")
    public String editData(@PathVariable Long id, Model model) {
        Panen data = panenRepository.findById(id).orElse(new Panen());
        model.addAttribute("panen", data); 
        model.addAttribute("listPanen", panenRepository.findAll());
        return "panen";
    }

    // Endpoint khusus AJAX untuk simpan tanpa reload saat klik Excel/PDF
    @PostMapping("/simpan")
    @ResponseBody
    public String simpanAjax(@ModelAttribute Panen panen) {
        try {
            // repository.save akan otomatis mengupdate jika id sudah ada (saat edit)
            // atau menambah baru jika id kosong
            panenRepository.save(panen);
            return "SUCCESS";
        } catch (Exception e) {
            return "ERROR";
        }
    }

    @GetMapping("/delete/{id}")
    public String deleteData(@PathVariable Long id) {
        panenRepository.deleteById(id);
        return "redirect:/panen";
    }
}