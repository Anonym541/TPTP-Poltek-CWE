package com.smartplanters.budgeting_app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smartplanters.budgeting_app.model.Pemupukan;
import com.smartplanters.budgeting_app.repository.PemupukanRepository;

@Controller
@RequestMapping("/pemupukan")
public class PemupukanController {

    @Autowired
    private PemupukanRepository pemupukanRepository;

    @GetMapping
    public String showForm(Model model) {
        model.addAttribute("pemupukan", new Pemupukan());
        model.addAttribute("listPemupukan", pemupukanRepository.findAll());
        return "pemupukan";
    }

    @PostMapping("/hitung")
    public String hitungAnggaran(@ModelAttribute Pemupukan pemupukan, Model model) {
        try {
            // Kalkulasi saja tanpa simpan
            hitungLogikaPemupukan(pemupukan);
            
            model.addAttribute("hasil", pemupukan);
            model.addAttribute("pemupukan", pemupukan);
            model.addAttribute("listPemupukan", pemupukanRepository.findAll());
        } catch (Exception e) {
            return "redirect:/pemupukan?error";
        }
        return "pemupukan";
    }

    @PostMapping("/simpan")
    @ResponseBody
    public String simpanData(@ModelAttribute Pemupukan pemupukan) {
        try {
            // KRUSIAL: Jika tujuannya menambah data baru, pastikan ID bernilai null.
            // Spring Data JPA melakukan 'save or update' berdasarkan keberadaan ID.
            pemupukan.setId(null); 
            
            hitungLogikaPemupukan(pemupukan);
            pemupukanRepository.save(pemupukan);
            
            return "SUCCESS"; 
        } catch (Exception e) {
            e.printStackTrace();
            return "ERROR";
        }
    }

    @GetMapping("/edit/{id}")
    public String editData(@PathVariable Long id, Model model) {
        Pemupukan dataLama = pemupukanRepository.findById(id).orElse(new Pemupukan());
        model.addAttribute("pemupukan", dataLama);
        model.addAttribute("hasil", dataLama); 
        model.addAttribute("listPemupukan", pemupukanRepository.findAll());
        return "pemupukan";
    }

    @GetMapping("/delete/{id}")
    public String deleteData(@PathVariable Long id) {
        try {
            pemupukanRepository.deleteById(id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "redirect:/pemupukan";
    }

    private void hitungLogikaPemupukan(Pemupukan p) {
        if (p.getJumlahHariKerja() <= 0 || p.getKemampuanTenaga() <= 0) return;

        // 1. KEBUTUHAN TK
        double rawTk = ((p.getLuasLahan() * p.getPokokPerHa()) / p.getJumlahHariKerja()) / p.getKemampuanTenaga();
        double kebutuhanTk = Math.floor(rawTk); 
        p.setKebutuhanTenagaPerHari(kebutuhanTk);
        
        double hkTotal = (p.getLuasLahan() * p.getPokokPerHa()) / p.getKemampuanTenaga();
        p.setKebutuhanTenaga(hkTotal);

        // 2. UPAH KARYAWAN
        double upahKaryawan = kebutuhanTk * p.getUpahPerHk() * p.getJumlahHariKerja();
        p.setTotalAnggaranLabour(upahKaryawan);

        // 3. KEBUTUHAN PUPUK (Per Sak 50kg)
        double kebutuhanPupuk = (p.getLuasLahan() * p.getPokokPerHa() * p.getDosis() * p.getRotasi()) / 50.0;
        p.setKebutuhanPupukSak(kebutuhanPupuk);

        // 4. ANGGARAN PUPUK
        double anggaranPupuk = kebutuhanPupuk * p.getHargaPupukPerSak();
        p.setBiayaPupuk(anggaranPupuk);
        p.setTotalAnggaranMaterial(anggaranPupuk);

        // 5. ANGGARAN TOOLS
        double anggaranApd = p.getHargaApd() * kebutuhanTk;
        double anggaranMangkok = p.getHargaMangkok() * kebutuhanTk;
        double anggaranEmber = p.getHargaEmber() * kebutuhanTk;
        
        p.setBiayaApd(anggaranApd);
        p.setBiayaMangkok(anggaranMangkok);
        p.setBiayaEmber(anggaranEmber);

        // 6. TOTAL TOOLS
        double totalTools = anggaranApd + anggaranMangkok + anggaranEmber;
        p.setTotalAnggaranTools(totalTools);

        // 7. GRAND TOTAL
        double grandTotal = upahKaryawan + anggaranPupuk + totalTools;
        p.setGrandTotalAnggaran(grandTotal);
    }
}