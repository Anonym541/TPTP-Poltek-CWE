package com.smartplanters.budgeting_app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smartplanters.budgeting_app.model.Pruning;
import com.smartplanters.budgeting_app.repository.PruningRepository; 

@Controller
@RequestMapping("/pruning")
public class PruningController {

    @Autowired
    private PruningRepository pruningRepository;

    @GetMapping
    public String pruningPage(Model model) {
        if (!model.containsAttribute("pruning")) {
            model.addAttribute("pruning", new Pruning());
        }
        model.addAttribute("listPruning", pruningRepository.findAll());
        return "pruning";
    }

    @PostMapping("/hitung")
    public String hitungPruning(@ModelAttribute("pruning") Pruning p, Model model) {
        kalkulasiData(p);
        model.addAttribute("hasil", p);
        model.addAttribute("pruning", p);
        model.addAttribute("listPruning", pruningRepository.findAll());
        return "pruning";
    }

    @GetMapping("/edit/{id}")
    public String editPruning(@PathVariable Long id, Model model) {
        Pruning data = pruningRepository.findById(id).orElse(new Pruning());
        model.addAttribute("pruning", data);
        model.addAttribute("listPruning", pruningRepository.findAll());
        return "pruning";
    }

    @PostMapping("/simpan")
    @ResponseBody
    public String simpanPruning(@ModelAttribute Pruning p) {
        try {
            kalkulasiData(p);
            pruningRepository.save(p);
            return "SUCCESS";
        } catch (Exception e) {
            return "ERROR";
        }
    }

    @GetMapping("/delete/{id}")
    public String deletePruning(@PathVariable("id") Long id) {
        pruningRepository.deleteById(id);
        return "redirect:/pruning";
    }

    private void kalkulasiData(Pruning p) {
        double luas = (p.getLuasLahan() != null) ? p.getLuasLahan() : 0;
        double sph = (p.getPokokPerHa() != null) ? p.getPokokPerHa() : 0;
        double rotasi = (p.getRotasi() != null) ? p.getRotasi() : 0;
        
        double jmlPokok = luas * sph * rotasi;
        p.setJumlahPokok(jmlPokok);

        double kemampuan = (p.getKemampuanTenaga() != null && p.getKemampuanTenaga() > 0) ? p.getKemampuanTenaga() : 1;
        double hari = (p.getJumlahHariKerja() != null && p.getJumlahHariKerja() > 0) ? p.getJumlahHariKerja() : 1;
        
        double tkPerHari = Math.floor(jmlPokok / (kemampuan * hari));
        p.setKebutuhanTenagaPerHari(tkPerHari);

        double upah = p.getUpahPerHk() != null ? p.getUpahPerHk() : 0;
        double totalUpah = jmlPokok * upah;
        p.setTotalAnggaranLabour(totalUpah);

        double bEgrek = tkPerHari * (p.getHargaEgrek() != null ? p.getHargaEgrek() : 0);
        double bParang = tkPerHari * (p.getHargaParang() != null ? p.getHargaParang() : 0);
        double bApd = tkPerHari * (p.getHargaApd() != null ? p.getHargaApd() : 0);

        p.setBiayaEgrek(bEgrek);
        p.setBiayaParang(bParang);
        p.setBiayaApd(bApd);

        double totalTools = bEgrek + bParang + bApd;
        p.setTotalAnggaranTools(totalTools);
        p.setGrandTotalAnggaran(totalUpah + totalTools);
    }
}