package com.smartplanters.budgeting_app.service;

import com.smartplanters.budgeting_app.model.Pemupukan;
import com.smartplanters.budgeting_app.repository.PemupukanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PemupukanService {

    @Autowired
    private PemupukanRepository repository;

    public Pemupukan hitungDanSimpan(Pemupukan data) {
        // Logika Dasar
        double totalPokok = data.getLuasLahan() * data.getPokokPerHa();
        int rot = data.getRotasi();

        // 1. Perhitungan Material (Pupuk)
        double kgPupuk = totalPokok * data.getDosis();
        double sakPupuk = kgPupuk / 50;
        data.setKebutuhanPupukSak(sakPupuk);
        
        // Biaya pupuk total berdasarkan rotasi
        double biayaPupukTotal = sakPupuk * data.getHargaPupukPerSak() * rot;
        data.setBiayaPupuk(biayaPupukTotal);

        // 2. Perhitungan Tenaga (Labour)
        double tenaga = totalPokok / data.getKemampuanTenaga();
        data.setKebutuhanTenaga(tenaga);
        
        // Menghitung kebutuhan tenaga kerja per hari
        if (data.getJumlahHariKerja() != null && data.getJumlahHariKerja() > 0) {
            data.setKebutuhanTenagaPerHari(tenaga / data.getJumlahHariKerja());
        } else {
            data.setKebutuhanTenagaPerHari(0.0);
        }
        
        data.setTotalAnggaranLabour(tenaga * data.getUpahPerHk() * rot);

        // 3. Perhitungan Tools (APD, Mangkok, Ember) - Biasanya dihitung per Luas Lahan
        data.setBiayaApd(data.getHargaApd() * data.getLuasLahan());
        data.setBiayaMangkok(data.getHargaMangkok() * data.getLuasLahan());
        data.setBiayaEmber(data.getHargaEmber() * data.getLuasLahan());
        
        double totalTools = data.getBiayaApd() + data.getBiayaMangkok() + data.getBiayaEmber();
        data.setTotalAnggaranTools(totalTools);

        // 4. Totals (Grand Total)
        data.setTotalAnggaranMaterial(biayaPupukTotal);
        data.setGrandTotalAnggaran(data.getTotalAnggaranLabour() + data.getTotalAnggaranMaterial() + data.getTotalAnggaranTools());

        // Simpan ke Database dan kembalikan hasil
        return repository.save(data);
    }
}