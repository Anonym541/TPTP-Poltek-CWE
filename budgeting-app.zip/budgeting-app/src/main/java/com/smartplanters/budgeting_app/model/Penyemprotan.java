package com.smartplanters.budgeting_app.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_penyemprotan")
public class Penyemprotan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // --- DATA INPUT (SESUAI GAMBAR) ---
    private Double luasLahan;
    private Integer pokokPerHa;
    private Integer rotasi;
    private Double kemampuanTenaga; // Ha/HK
    private Integer jumlahHariKerja;
    private Double upahPerHk;
    
    // Parameter Teknis
    private Double lebarPiringan;
    private Integer jumlahPasarPikul;
    private Double lebarPasarPikul;
    private Integer panjangPasarPikul;
    
    // Material & Alat
    private String jenisHerbisida;
    private Double dosisHerbisida;
    private Double hargaHerbisida;
    private Double hargaKnapsack;
    private Double hargaApd;

    // --- HASIL PERHITUNGAN ---
    private Double totalAnggaranLabour;
    private Double totalAnggaranMaterial;
    private Double totalAnggaranTools;
    private Double grandTotalAnggaran;

    // --- CONSTRUCTOR ---
    public Penyemprotan() {}

    // --- GETTER & SETTER ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Double getLuasLahan() { return luasLahan; }
    public void setLuasLahan(Double luasLahan) { this.luasLahan = luasLahan; }

    public Integer getPokokPerHa() { return pokokPerHa; }
    public void setPokokPerHa(Integer pokokPerHa) { this.pokokPerHa = pokokPerHa; }

    public Integer getRotasi() { return rotasi; }
    public void setRotasi(Integer rotasi) { this.rotasi = rotasi; }

    public Double getKemampuanTenaga() { return kemampuanTenaga; }
    public void setKemampuanTenaga(Double kemampuanTenaga) { this.kemampuanTenaga = kemampuanTenaga; }

    public Integer getJumlahHariKerja() { return jumlahHariKerja; }
    public void setJumlahHariKerja(Integer jumlahHariKerja) { this.jumlahHariKerja = jumlahHariKerja; }

    public Double getUpahPerHk() { return upahPerHk; }
    public void setUpahPerHk(Double upahPerHk) { this.upahPerHk = upahPerHk; }

    public Double getLebarPiringan() { return lebarPiringan; }
    public void setLebarPiringan(Double lebarPiringan) { this.lebarPiringan = lebarPiringan; }

    public Integer getJumlahPasarPikul() { return jumlahPasarPikul; }
    public void setJumlahPasarPikul(Integer jumlahPasarPikul) { this.jumlahPasarPikul = jumlahPasarPikul; }

    public Double getLebarPasarPikul() { return lebarPasarPikul; }
    public void setLebarPasarPikul(Double lebarPasarPikul) { this.lebarPasarPikul = lebarPasarPikul; }

    public Integer getPanjangPasarPikul() { return panjangPasarPikul; }
    public void setPanjangPasarPikul(Integer panjangPasarPikul) { this.panjangPasarPikul = panjangPasarPikul; }

    public String getJenisHerbisida() { return jenisHerbisida; }
    public void setJenisHerbisida(String jenisHerbisida) { this.jenisHerbisida = jenisHerbisida; }

    public Double getDosisHerbisida() { return dosisHerbisida; }
    public void setDosisHerbisida(Double dosisHerbisida) { this.dosisHerbisida = dosisHerbisida; }

    public Double getHargaHerbisida() { return hargaHerbisida; }
    public void setHargaHerbisida(Double hargaHerbisida) { this.hargaHerbisida = hargaHerbisida; }

    public Double getHargaKnapsack() { return hargaKnapsack; }
    public void setHargaKnapsack(Double hargaKnapsack) { this.hargaKnapsack = hargaKnapsack; }

    public Double getHargaApd() { return hargaApd; }
    public void setHargaApd(Double hargaApd) { this.hargaApd = hargaApd; }

    // SETTER & GETTER HASIL
    public Double getTotalAnggaranLabour() { return totalAnggaranLabour; }
    public void setTotalAnggaranLabour(Double totalAnggaranLabour) { this.totalAnggaranLabour = totalAnggaranLabour; }

    public Double getTotalAnggaranMaterial() { return totalAnggaranMaterial; }
    public void setTotalAnggaranMaterial(Double totalAnggaranMaterial) { this.totalAnggaranMaterial = totalAnggaranMaterial; }

    public Double getTotalAnggaranTools() { return totalAnggaranTools; }
    public void setTotalAnggaranTools(Double totalAnggaranTools) { this.totalAnggaranTools = totalAnggaranTools; }

    public Double getGrandTotalAnggaran() { return grandTotalAnggaran; }
    public void setGrandTotalAnggaran(Double grandTotalAnggaran) { this.grandTotalAnggaran = grandTotalAnggaran; }
}