package com.smartplanters.budgeting_app.model;

import lombok.Data;

@Data // Jika pakai Lombok, jika tidak buat Getter & Setter manual
public class HasilPerhitungan {
    private double kebutuhanPupukSak;
    private double totalAnggaranMaterial;
    private double kebutuhanTenaga;
    private double kebutuhanTenagaPerHari;
    private double totalAnggaranLabour;
    private double totalAnggaranTools;
    private double biayaPupuk;
    private double biayaApd;
    private double biayaMangkok;
    private double biayaEmber;
    private double grandTotalAnggaran;
}