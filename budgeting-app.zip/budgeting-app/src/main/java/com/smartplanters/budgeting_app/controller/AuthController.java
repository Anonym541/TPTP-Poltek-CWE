package com.smartplanters.budgeting_app.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.smartplanters.budgeting_app.model.User;
import com.smartplanters.budgeting_app.repository.UserRepository;

@Controller
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    // PROSES REGISTER: Simpan user ke MySQL
    @PostMapping("/register")
    public String processRegister(@RequestParam String fullName, 
                                  @RequestParam String username, 
                                  @RequestParam String password) {
        User user = new User();
        user.setFullName(fullName);
        user.setUsername(username);
        user.setPassword(password); 
        
        userRepository.save(user); 
        return "redirect:/login"; 
    }

    // PROSES LOGIN: Cek data ke MySQL
    @PostMapping("/login")
    public String processLogin(@RequestParam String username, 
                               @RequestParam String password, 
                               Model model) {
        Optional<User> userFound = userRepository.findByUsername(username);
        
        if (userFound.isPresent() && userFound.get().getPassword().equals(password)) {
            return "redirect:/dashboard"; 
        } else {
            model.addAttribute("error", "Username atau Password salah!"); 
            return "login"; 
        }
    }

    // --- FITUR LUPA PASSWORD ---

    @GetMapping("/forgot-password")
    public String forgotPasswordPage() {
        return "forgot-password";
    }

    @PostMapping("/forgot-password")
    public String processForgotPassword(@RequestParam String username, 
                                        @RequestParam String newPassword, 
                                        @RequestParam String confirmPassword, 
                                        Model model,
                                        RedirectAttributes redirectAttributes) {
        
        Optional<User> userOptional = userRepository.findByUsername(username);
        
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            
            // Validasi apakah password baru dan konfirmasi cocok
            if (newPassword.equals(confirmPassword)) {
                
                // Set password baru ke objek user
                user.setPassword(newPassword);
                
                // Simpan perubahan (JPA otomatis menjalankan query UPDATE karena ID sudah ada)
                userRepository.save(user);
                
                // Gunakan flash attribute agar pesan muncul setelah redirect ke login
                redirectAttributes.addFlashAttribute("message", "Password berhasil diperbarui! Silakan masuk.");
                return "redirect:/login";
            } else {
                model.addAttribute("error", "Konfirmasi password tidak cocok!");
                return "forgot-password";
            }
        } else {
            model.addAttribute("error", "Username tidak ditemukan!");
            return "forgot-password";
        }
    }

    @GetMapping("/dashboard")
    public String dashboard() {
        return "dashboard";
    }
}