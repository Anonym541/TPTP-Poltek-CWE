package com.smartplanters.budgeting_app.controller;

public class HasilPerhitungan {
    
}
