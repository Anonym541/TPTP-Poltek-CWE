package com.smartplanters.budgeting_app.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_pemupukan")
public class Pemupukan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // --- DATA INPUT ---
    private Double luasLahan;
    private Integer pokokPerHa;
    private Double dosis;
    private Integer rotasi;
    private String jenisPupuk; // Variabel baru untuk jenis pupuk
    private Double hargaPupukPerSak;
    private Double kemampuanTenaga; 
    private Double upahPerHk;
    private Double hargaApd;
    private Double hargaMangkok;
    private Double hargaEmber;
    private Integer jumlahHariKerja;

    // --- HASIL PERHITUNGAN ---
    private Double kebutuhanTenaga;
    private Double kebutuhanTenagaPerHari;
    private Double kebutuhanPupukSak;
    private Double biayaPupuk;
    private Double biayaApd;
    private Double biayaMangkok;
    private Double biayaEmber;
    private Double totalAnggaranLabour;
    private Double totalAnggaranMaterial;
    private Double totalAnggaranTools;
    private Double grandTotalAnggaran;

    // --- CONSTRUCTOR ---
    public Pemupukan() {}

    // --- GETTER & SETTER DATA INPUT ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Double getLuasLahan() { return luasLahan; }
    public void setLuasLahan(Double luasLahan) { this.luasLahan = luasLahan; }

    public Integer getPokokPerHa() { return pokokPerHa; }
    public void setPokokPerHa(Integer pokokPerHa) { this.pokokPerHa = pokokPerHa; }

    public Double getDosis() { return dosis; }
    public void setDosis(Double dosis) { this.dosis = dosis; }

    public Integer getRotasi() { return rotasi; }
    public void setRotasi(Integer rotasi) { this.rotasi = rotasi; }

    public String getJenisPupuk() { return jenisPupuk; }
    public void setJenisPupuk(String jenisPupuk) { this.jenisPupuk = jenisPupuk; }

    public Double getHargaPupukPerSak() { return hargaPupukPerSak; }
    public void setHargaPupukPerSak(Double hargaPupukPerSak) { this.hargaPupukPerSak = hargaPupukPerSak; }

    public Double getKemampuanTenaga() { return kemampuanTenaga; }
    public void setKemampuanTenaga(Double kemampuanTenaga) { this.kemampuanTenaga = kemampuanTenaga; }

    public Double getUpahPerHk() { return upahPerHk; }
    public void setUpahPerHk(Double upahPerHk) { this.upahPerHk = upahPerHk; }

    public Double getHargaApd() { return hargaApd; }
    public void setHargaApd(Double hargaApd) { this.hargaApd = hargaApd; }

    public Double getHargaMangkok() { return hargaMangkok; }
    public void setHargaMangkok(Double hargaMangkok) { this.hargaMangkok = hargaMangkok; }

    public Double getHargaEmber() { return hargaEmber; }
    public void setHargaEmber(Double hargaEmber) { this.hargaEmber = hargaEmber; }

    public Integer getJumlahHariKerja() { return jumlahHariKerja; }
    public void setJumlahHariKerja(Integer jumlahHariKerja) { this.jumlahHariKerja = jumlahHariKerja; }

    // --- GETTER & SETTER HASIL PERHITUNGAN ---
    public Double getKebutuhanTenaga() { return kebutuhanTenaga; }
    public void setKebutuhanTenaga(Double kebutuhanTenaga) { this.kebutuhanTenaga = kebutuhanTenaga; }

    public Double getKebutuhanTenagaPerHari() { return kebutuhanTenagaPerHari; }
    public void setKebutuhanTenagaPerHari(Double kebutuhanTenagaPerHari) { this.kebutuhanTenagaPerHari = kebutuhanTenagaPerHari; }

    public Double getKebutuhanPupukSak() { return kebutuhanPupukSak; }
    public void setKebutuhanPupukSak(Double kebutuhanPupukSak) { this.kebutuhanPupukSak = kebutuhanPupukSak; }

    public Double getBiayaPupuk() { return biayaPupuk; }
    public void setBiayaPupuk(Double biayaPupuk) { this.biayaPupuk = biayaPupuk; }

    public Double getBiayaApd() { return biayaApd; }
    public void setBiayaApd(Double biayaApd) { this.biayaApd = biayaApd; }

    public Double getBiayaMangkok() { return biayaMangkok; }
    public void setBiayaMangkok(Double biayaMangkok) { this.biayaMangkok = biayaMangkok; }

    public Double getBiayaEmber() { return biayaEmber; }
    public void setBiayaEmber(Double biayaEmber) { this.biayaEmber = biayaEmber; }

    public Double getTotalAnggaranLabour() { return totalAnggaranLabour; }
    public void setTotalAnggaranLabour(Double totalAnggaranLabour) { this.totalAnggaranLabour = totalAnggaranLabour; }

    public Double getTotalAnggaranMaterial() { return totalAnggaranMaterial; }
    public void setTotalAnggaranMaterial(Double totalAnggaranMaterial) { this.totalAnggaranMaterial = totalAnggaranMaterial; }

    public Double getTotalAnggaranTools() { return totalAnggaranTools; }
    public void setTotalAnggaranTools(Double totalAnggaranTools) { this.totalAnggaranTools = totalAnggaranTools; }

    public Double getGrandTotalAnggaran() { return grandTotalAnggaran; }
    public void setGrandTotalAnggaran(Double grandTotalAnggaran) { this.grandTotalAnggaran = grandTotalAnggaran; }
}