package com.smartplanters.budgeting_app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smartplanters.budgeting_app.model.Penyemprotan;
import com.smartplanters.budgeting_app.repository.PenyemprotanRepository;

@Controller
@RequestMapping("/penyemprotan")
public class PenyemprotanController {

    @Autowired
    private PenyemprotanRepository penyemprotanRepository;

    @GetMapping
    public String showForm(Model model) {
        if (!model.containsAttribute("penyemprotan")) {
            model.addAttribute("penyemprotan", new Penyemprotan());
        }
        model.addAttribute("listPenyemprotan", penyemprotanRepository.findAll());
        return "penyemprotan";
    }

    @PostMapping("/hitung")
    public String hitungAnggaran(@ModelAttribute Penyemprotan penyemprotan, Model model) {
        kalkulasiPenyemprotan(penyemprotan);
        
        model.addAttribute("hasil", penyemprotan);
        model.addAttribute("penyemprotan", penyemprotan);
        model.addAttribute("listPenyemprotan", penyemprotanRepository.findAll());
        return "penyemprotan";
    }

    @GetMapping("/edit/{id}")
    public String editData(@PathVariable Long id, Model model) {
        Penyemprotan data = penyemprotanRepository.findById(id).orElse(new Penyemprotan());
        model.addAttribute("penyemprotan", data);
        model.addAttribute("hasil", data); // Menampilkan hasil perhitungan terakhir data tersebut
        model.addAttribute("listPenyemprotan", penyemprotanRepository.findAll());
        return "penyemprotan";
    }

    @PostMapping("/simpan")
    @ResponseBody
    public String simpanData(@ModelAttribute Penyemprotan penyemprotan) {
        try {
            kalkulasiPenyemprotan(penyemprotan);
            penyemprotanRepository.save(penyemprotan);
            return "SUCCESS";
        } catch (Exception e) {
            return "ERROR";
        }
    }

    @GetMapping("/delete/{id}")
    public String deleteData(@PathVariable Long id) {
        penyemprotanRepository.deleteById(id);
        return "redirect:/penyemprotan";
    }

    private void kalkulasiPenyemprotan(Penyemprotan p) {
        double luas = p.getLuasLahan();
        double sph = p.getPokokPerHa();
        double rotasi = (double) p.getRotasi();
        double kemampuan = p.getKemampuanTenaga();
        double upah = p.getUpahPerHk();
        double hariKerja = p.getJumlahHariKerja();

        // Kebutuhan TK
        double kebutuhanTk = (luas * rotasi) / kemampuan / hariKerja;
        double tkBulat = Math.round(kebutuhanTk);

        double upahKaryawan = (upah * luas * rotasi) / kemampuan;
        double luasPiringan = (3.14 * p.getLebarPiringan() * luas * sph * rotasi) / 10000;
        double luasPasarPikul = (p.getJumlahPasarPikul() * p.getLebarPasarPikul() * luas * rotasi) / 10000;
        
        double kebutuhanHerbisida = p.getDosisHerbisida() * (luasPiringan + luasPasarPikul);
        double hargaHerbisidaTotal = kebutuhanHerbisida * p.getHargaHerbisida();

        double totalHargaKnapsack = p.getHargaKnapsack() * tkBulat;
        double totalHargaApd = p.getHargaApd() * tkBulat;

        p.setTotalAnggaranLabour(upahKaryawan);
        p.setTotalAnggaranMaterial(hargaHerbisidaTotal);
        p.setTotalAnggaranTools(totalHargaKnapsack + totalHargaApd);
        p.setGrandTotalAnggaran(upahKaryawan + hargaHerbisidaTotal + (totalHargaKnapsack + totalHargaApd));
    }
}