package com.smartplanters.budgeting_app.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_panen")
public class Panen {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // INPUT
    private Double luasLahan;
    private Integer pokokPerHa;
    private Double akp;
    private Double bjr;
    private Integer intervalPanen;
    private Double kemampuanTenaga;
    private Double rotasi;
    //private Integer hariKerja;
    private Double upahPerHk;
    private Double hargaEgrek;
    private Double hargaTojok;
    private Double hargaAngkong;
    private Double hargaApd;
    private Double hargaGancu;

    // OUTPUT (Sesuai Gambar Hasil)
    private Double tonase;
    private Double kebutuhanTk;
    private Double upahKaryawan;
    private Double totalAnggaranLabour;
    private Double totalAnggaranTools;
    private Double grandTotalAnggaran;

    public Panen() {}

    // GETTER & SETTER (Pastikan semua digenerate agar bisa dibaca Thymeleaf)
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Double getLuasLahan() { return luasLahan; }
    public void setLuasLahan(Double luasLahan) { this.luasLahan = luasLahan; }
    public Integer getPokokPerHa() { return pokokPerHa; }
    public void setPokokPerHa(Integer pokokPerHa) { this.pokokPerHa = pokokPerHa; }
    public Double getAkp() { return akp; }
    public void setAkp(Double akp) { this.akp = akp; }
    public Double getBjr() { return bjr; }
    public void setBjr(Double bjr) { this.bjr = bjr; }
    public Integer getIntervalPanen() { return intervalPanen; }
    public void setIntervalPanen(Integer intervalPanen) { this.intervalPanen = intervalPanen; }
    public Double getKemampuanTenaga() { return kemampuanTenaga; }
    public void setKemampuanTenaga(Double kemampuanTenaga) { this.kemampuanTenaga = kemampuanTenaga; }
    //public Integer getHariKerja() { return hariKerja; }
    //public void setHariKerja(Integer hariKerja) { this.hariKerja = hariKerja; }
    public Double getUpahPerHk() { return upahPerHk; }
    public void setUpahPerHk(Double upahPerHk) { this.upahPerHk = upahPerHk; }
    public Double getHargaEgrek() { return hargaEgrek; }
    public void setHargaEgrek(Double hargaEgrek) { this.hargaEgrek = hargaEgrek; }
    public Double getHargaTojok() { return hargaTojok; }
    public void setHargaTojok(Double hargaTojok) { this.hargaTojok = hargaTojok; }
    public Double getHargaAngkong() { return hargaAngkong; }
    public void setHargaAngkong(Double hargaAngkong) { this.hargaAngkong = hargaAngkong; }
    public Double getHargaApd() { return hargaApd; }
    public void setHargaApd(Double hargaApd) { this.hargaApd = hargaApd; }
    public Double getHargaGancu() { return hargaGancu; }
    public void setHargaGancu(Double hargaGancu) { this.hargaGancu = hargaGancu; }
    public Double getTonase() { return tonase; }
    public void setTonase(Double tonase) { this.tonase = tonase; }
    public Double getKebutuhanTk() { return kebutuhanTk; }
    public void setKebutuhanTk(Double kebutuhanTk) { this.kebutuhanTk = kebutuhanTk; }
    public Double getUpahKaryawan() { return upahKaryawan; }
    public void setUpahKaryawan(Double upahKaryawan) { this.upahKaryawan = upahKaryawan; }
    public Double getTotalAnggaranLabour() { return totalAnggaranLabour; }
    public void setTotalAnggaranLabour(Double totalAnggaranLabour) { this.totalAnggaranLabour = totalAnggaranLabour; }
    public Double getTotalAnggaranTools() { return totalAnggaranTools; }
    public void setTotalAnggaranTools(Double totalAnggaranTools) { this.totalAnggaranTools = totalAnggaranTools; }
    public Double getGrandTotalAnggaran() { return grandTotalAnggaran; }
    public void setGrandTotalAnggaran(Double grandTotalAnggaran) { this.grandTotalAnggaran = grandTotalAnggaran; }
    public Double getRotasi() { return rotasi; }
    public void setRotasi(Double rotasi) { this.rotasi = rotasi; }
}